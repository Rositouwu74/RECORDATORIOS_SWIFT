//
//  DeleteRemindersView.swift
//  Recordatorios
//
//  Created by Erick David Gómez Guadiana on 08/11/24.
//

import SwiftUI
import Foundation
import UIKit

struct DeletedRemindersView: View {
    @Binding var reminders: [Reminder]
    @Environment(\.dismiss) var dismiss
    @Environment(\.colorScheme) var colorScheme
    
    private var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.gray.opacity(0.1)
    }
    
    private var deletedReminders: [Reminder] {
        reminders.filter { reminder in
            guard reminder.isDeleted, let deletedAt = reminder.deletedAt else { return false }
            return Date().timeIntervalSince(deletedAt) < 24 * 60 * 60
        }
    }
    
    var body: some View {
        ZStack {
            backgroundColor
                .ignoresSafeArea()
            
            if deletedReminders.isEmpty {
                VStack(spacing: 20) {
                    Image(systemName: "trash.slash.fill")
                        .font(.system(size: 60))
                        .foregroundColor(.gray.opacity(0.3))
                    
                    Text("No hay recordatorios eliminados.")
                        .font(.title3)
                        .fontWeight(.medium)
                        .foregroundColor(.gray)
                }
            } else {
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(deletedReminders) { reminder in
                            DeletedReminderCard(reminder: reminder, reminders: $reminders)
                                .padding(.horizontal)
                        }
                    }
                    .padding(.vertical)
                }
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    dismiss()
                } label: {
                    HStack {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    }
                    .foregroundColor(.pink)
                }
            }
            ToolbarItem(placement: .principal) {
                Text("Papelera")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.pink)
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                if !deletedReminders.isEmpty {
                    Button {
                        deleteAllPermanently()
                    } label: {
                        Image(systemName: "trash")
                            .font(.title2)
                            .foregroundColor(.red)
                    }
                }
            }
        }
    }
    
    private func deleteAllPermanently() {
        withAnimation {
            reminders.removeAll(where: { $0.isDeleted })
        }
    }
}

struct DeletedReminderCard: View {
    let reminder: Reminder
    @Binding var reminders: [Reminder]
    
    private var timeRemaining: String {
        guard let deletedAt = reminder.deletedAt else { return "" }
        let timeRemaining = 24 * 60 * 60 - Date().timeIntervalSince(deletedAt)
        let hours = Int(timeRemaining / 3600)
        let minutes = Int((timeRemaining.truncatingRemainder(dividingBy: 3600)) / 60)
        return "\(hours)h \(minutes)m"
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
    
    private func formatTime(_ time: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: time)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "trash.circle.fill")
                    .foregroundColor(.pink)
                    .font(.title2)
                
                Text(reminder.text)
                    .font(.headline)
                
                Spacer()
                
                Text(timeRemaining)
                    .font(.caption)
                    .foregroundColor(.orange)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.orange.opacity(0.2))
                    .cornerRadius(8)
            }
            
            if let date = reminder.date {
                Label(formatDate(date), systemImage: "calendar")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            if let time = reminder.time {
                Label(formatTime(time), systemImage: "clock")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            HStack(spacing: 12) {
                Button(action: restoreReminder) {
                    Label("Restaurar", systemImage: "arrow.uturn.backward")
                        .font(.subheadline)
                        .foregroundColor(.blue)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 12)
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(8)
                }
                
                Button(action: deletePermanently) {
                    Label("Eliminar", systemImage: "trash")
                        .font(.subheadline)
                        .foregroundColor(.red)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 12)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(8)
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
    
    private func restoreReminder() {
        if let index = reminders.firstIndex(where: { $0.id == reminder.id }) {
            withAnimation {
                reminders[index].isDeleted = false
                reminders[index].deletedAt = nil
                
                // Reprogramar notificación si la fecha/hora es futura
                if let date = reminder.date,
                   let time = reminder.time {
                    let calendar = Calendar.current
                    var dateComponents = calendar.dateComponents([.year, .month, .day], from: date)
                    let timeComponents = calendar.dateComponents([.hour, .minute], from: time)
                    dateComponents.hour = timeComponents.hour
                    dateComponents.minute = timeComponents.minute
                    
                    if let combinedDate = calendar.date(from: dateComponents),
                       combinedDate > Date() {
                        NotificationManager.shared.scheduleNotification(for: reminders[index])
                    }
                }
            }
        }
    }
    
    private func deletePermanently() {
        withAnimation {
            reminders.removeAll(where: { $0.id == reminder.id })
        }
    }
}
