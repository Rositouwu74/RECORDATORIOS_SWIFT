//
//  ReminderDetailView.swift
//  Recordatorios
//
//  Created by Erick David Gómez Guadiana on 08/11/24.
//

import SwiftUI
import Foundation

struct ReminderDetailView: View {
    let reminder: Reminder
    @Binding var reminders: [Reminder]
    @Environment(\.presentationMode) var presentationMode
    @State private var showEditSheet = false
    
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        return formatter
    }()
    
    private let timeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter
    }()
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Encabezado
                HStack {
                    Image(systemName: "bell.circle.fill")
                        .foregroundColor(.pink)
                        .font(.system(size: 30))
                    
                    Text(reminder.text)
                        .font(.title2)
                        .fontWeight(.bold)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color(UIColor.secondarySystemBackground))
                .cornerRadius(15)
                
                // Detalles de fecha y hora
                VStack(alignment: .leading, spacing: 15) {
                    Text("Detalles")
                        .font(.headline)
                        .foregroundColor(.pink)
                    
                    if let date = reminder.date {
                        HStack {
                            Image(systemName: "calendar")
                                .foregroundColor(.gray)
                            Text("Fecha:")
                                .foregroundColor(.gray)
                            Text(dateFormatter.string(from: date))
                                .fontWeight(.medium)
                        }
                    }
                    
                    if let time = reminder.time {
                        HStack {
                            Image(systemName: "clock")
                                .foregroundColor(.gray)
                            Text("Hora:")
                                .foregroundColor(.gray)
                            Text(timeFormatter.string(from: time))
                                .fontWeight(.medium)
                        }
                    }
                    
                    // Estado del recordatorio
                    HStack {
                        Image(systemName: "checkmark.circle")
                            .foregroundColor(.gray)
                        Text("Estado:")
                            .foregroundColor(.gray)
                        Text(isReminderPast ? "Vencido" : "Pendiente")
                            .fontWeight(.medium)
                            .foregroundColor(isReminderPast ? .red : .green)
                    }
                }
                .padding()
                .background(Color(UIColor.secondarySystemBackground))
                .cornerRadius(15)
                
                // Acciones
                VStack(spacing: 15) {
                    Button(action: {
                        showEditSheet = true
                    }) {
                        HStack {
                            Image(systemName: "pencil")
                            Text("Editar Recordatorio")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.pink)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    
                    Button(action: deleteReminder) {
                        HStack {
                            Image(systemName: "trash")
                            Text("Eliminar Recordatorio")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red.opacity(0.1))
                        .foregroundColor(.red)
                        .cornerRadius(10)
                    }
                }
                .padding()
                .background(Color(UIColor.secondarySystemBackground))
                .cornerRadius(15)
            }
            .padding()
        }
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showEditSheet) {
            if let index = reminders.firstIndex(where: { $0.id == reminder.id }) {
                EditReminderView(reminder: $reminders[index], reminders: $reminders)
            }
        }
    }
    
    private var isReminderPast: Bool {
        if let date = reminder.date {
            if let time = reminder.time {
                let calendar = Calendar.current
                var dateComponents = calendar.dateComponents([.year, .month, .day], from: date)
                let timeComponents = calendar.dateComponents([.hour, .minute], from: time)
                dateComponents.hour = timeComponents.hour
                dateComponents.minute = timeComponents.minute
                
                if let combinedDate = calendar.date(from: dateComponents) {
                    return combinedDate < Date()
                }
            }
            return Calendar.current.startOfDay(for: date) < Calendar.current.startOfDay(for: Date())
        }
        return false
    }
    
    private func deleteReminder() {
        if let index = reminders.firstIndex(where: { $0.id == reminder.id }) {
            NotificationManager.shared.cancelNotification(for: reminder)
            withAnimation {
                reminders[index].isDeleted = true
                reminders[index].deletedAt = Date()
            }
            presentationMode.wrappedValue.dismiss()
        }
    }
}
