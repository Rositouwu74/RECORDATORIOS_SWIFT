//
//  ReminderCard.swift
//  Recordatorios
//
//  Created by Erick David Gómez Guadiana on 08/11/24.
//

import SwiftUI

struct ReminderCard: View {
    let reminder: Reminder
    @Binding var reminders: [Reminder]
    @Binding var selectedReminder: Reminder?
    
    private var reminderColor: Color {
        let now = Date()
        let calendar = Calendar.current
        
        if let date = reminder.date {
            if let time = reminder.time {
                var dateComponents = calendar.dateComponents([.year, .month, .day], from: date)
                let timeComponents = calendar.dateComponents([.hour, .minute], from: time)
                dateComponents.hour = timeComponents.hour
                dateComponents.minute = timeComponents.minute
                
                if let combinedDateTime = calendar.date(from: dateComponents) {
                    if combinedDateTime < now {
                        return .red // Vencido
                    } else if calendar.isDateInToday(date) {
                        return .orange // Hoy
                    } else if calendar.isDateInTomorrow(date) {
                        return .yellow // Mañana
                    }
                }
            } else {
                if calendar.isDateInToday(date) {
                    return .yellow
                } else if calendar.isDateInTomorrow(date) {
                    return .orange
                } else if date < calendar.startOfDay(for: now) {
                    return .red
                }
            }
        }
        return .green
    }
    
    var body: some View {
        NavigationLink(destination: ReminderDetailView(reminder: reminder, reminders: $reminders)) {
            HStack(spacing: 15) {
                Circle()
                    .fill(reminderColor)
                    .frame(width: 12, height: 12)
                
                Text(reminder.text)
                    .font(.headline)
                    .lineLimit(1)
                    .foregroundColor(.primary)
                
                Spacer()
                
                if let date = reminder.date {
                    HStack(spacing: 12) {
                        Label(formatDate(date), systemImage: "calendar")
                            .font(.caption)
                            .foregroundColor(.gray)
                        
                        if let time = reminder.time {
                            Label(formatTime(time), systemImage: "clock")
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                    }
                }
            }
            .padding()
            .background(Color(.systemBackground))
            .cornerRadius(15)
            .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 2)
        }
        .padding(.horizontal)
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
    
    private func formatTime(_ time: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: time)
    }
}
