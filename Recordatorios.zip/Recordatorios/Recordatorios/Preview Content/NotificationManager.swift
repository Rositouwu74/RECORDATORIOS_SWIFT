//
//  NotificationManager.swift
//  Recordatorios
//
//  Created by Erick David Gómez Guadiana on 08/11/24.
//

import Foundation
import UserNotifications

class NotificationManager {
    static let shared = NotificationManager()
    
    private init() {}
    
    func scheduleNotification(for reminder: Reminder) {
        let content = UNMutableNotificationContent()
        content.title = "Recordatorio"
        content.body = reminder.text
        content.sound = .default
        
        if let date = reminder.date, let time = reminder.time {
            var dateComponents = Calendar.current.dateComponents([.year, .month, .day], from: date)
            let timeComponents = Calendar.current.dateComponents([.hour, .minute], from: time)
            dateComponents.hour = timeComponents.hour
            dateComponents.minute = timeComponents.minute
            
            let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
            let request = UNNotificationRequest(identifier: reminder.notificationIdentifier,
                                             content: content,
                                             trigger: trigger)
            
            UNUserNotificationCenter.current().add(request) { error in
                if let error = error {
                    print("Error al programar la notificación: \(error)")
                }
            }
        }
    }
    
    func cancelNotification(for reminder: Reminder) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(
            withIdentifiers: [reminder.notificationIdentifier]
        )
    }
    
    func updateNotification(for reminder: Reminder) {
        cancelNotification(for: reminder)
        scheduleNotification(for: reminder)
    }
}

// Extensión para Reminder para manejar identificadores de notificación
extension Reminder {
    var notificationIdentifier: String {
        "reminder_\(id.uuidString)"
    }
}
